<?php
/**
 * Output the checkout form when empty.
 *
 * This template can be overridden by copying it to {yourtheme}/awebooking/checkout/empty.php.
 *
 * @see      http://docs.awethemes.com/awebooking/developers/theme-developers/
 * @author   awethemes
 * @package  AweBooking
 * @version  3.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

