<table class="subcopy" width="100%" cellpadding="0" cellspacing="0">
	<tr>
		<td>
			<?php echo wp_kses_post( wpautop( wptexturize( $slot ) ) ); ?>
		</td>
	</tr>
</table>
