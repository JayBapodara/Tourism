<?php
namespace AweBooking\Component\Http\Exceptions;

class NonceMismatchException extends \Exception {}
