<div class="scheduler__header">
	<div class="scheduler__header-aside">
		<div class="scheduler__legends">
			<?php $calendar->call( 'display_legends' ); ?>
		</div>
	</div><!-- /.scheduler__header-aside -->

	<div class="scheduler__header-toolbar">
		<div class="scheduler-flex">
			<?php $calendar->call( 'display_toolbar' ); ?>
		</div>
	</div><!-- /.scheduler__header-toolbar -->
</div><!-- /.scheduler__header -->
