<?php

namespace AweBooking\Gateway;

class GatewayException extends \RuntimeException {}
