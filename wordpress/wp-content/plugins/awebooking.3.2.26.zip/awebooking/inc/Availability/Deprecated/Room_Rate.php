<?php

namespace AweBooking\Availability\Deprecated;

trait Room_Rate {
	public function has_error( $code = null ) {}
}
