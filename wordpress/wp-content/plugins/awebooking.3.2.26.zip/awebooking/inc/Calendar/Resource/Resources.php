<?php

namespace AweBooking\Calendar\Resource;

use AweBooking\Support\Collection;

class Resources extends Collection {}
