<?php

namespace AweBooking\Calendar\Exceptions;

class UntrustedResourceException extends \RuntimeException {}
