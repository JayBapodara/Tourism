<?php

namespace AweBooking\Checkout;

class RuntimeException extends \RuntimeException {}
