<?php

namespace AweBooking\Reservation\Exceptions;

class NotEnoughRoomsException extends \OverflowException {}
