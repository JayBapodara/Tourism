<?php

namespace AweBooking\Reservation\Exceptions;

class RestoreException extends \RuntimeException {}
