<?php

namespace AweBooking\Reservation\Exceptions;

class FullyBookedException extends \RuntimeException {}
