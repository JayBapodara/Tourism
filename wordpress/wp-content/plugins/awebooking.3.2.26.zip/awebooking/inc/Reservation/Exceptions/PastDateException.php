<?php

namespace AweBooking\Reservation\Exceptions;

class PastDateException extends \RuntimeException {}
